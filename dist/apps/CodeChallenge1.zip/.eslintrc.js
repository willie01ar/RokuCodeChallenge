module.exports = {
  extends: 'plugin:roku/recommended',
  rules: {
    'roku/no-print': 'warn',
    'roku/no-stop': 'warn',
    'roku/sub-to-function': 'off',
    'roku/function-no-return': 'off'
  }
}
